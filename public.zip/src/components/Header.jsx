// src/components/Header.jsx
import { Link } from "react-router-dom";
import projectData from "../data/projectdata.json";

export default function Header() {
  return (
    <header className="w-full bg-[var(--color-surface)]/80 backdrop-blur-md border-b border-[var(--color-border)]">
      <nav className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">

        {/* Logo */}
        <Link 
          to="/" 
          className="text-lg font-semibold text-[var(--color-text)] hover:text-[var(--color-accent)] transition"
        >
          Mijn Portfolio
        </Link>

        {/* Navigation */}
        <div className="flex items-center gap-8">

          <Link 
            to="/" 
            className="text-sm text-[var(--color-muted)] hover:text-[var(--color-accent)] transition"
          >
            Home
          </Link>

          <Link 
            to="/about" 
            className="text-sm text-[var(--color-muted)] hover:text-[var(--color-accent)] transition"
          >
            About Me
          </Link>

          {/* Dropdown */}
          <div className="relative group">
            <button className="text-sm text-[var(--color-muted)] hover:text-[var(--color-accent)] transition flex items-center gap-1">
              Projecten
              <span className="text-xs">▾</span>
            </button>

            {/* Dropdown menu */}
            <div className="absolute right-0 mt-2 w-48 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-lg shadow-xl opacity-0 translate-y-1 pointer-events-none group-hover:opacity-100 group-hover:translate-y-0 group-hover:pointer-events-auto transition">

              {projectData.projects.map((project) => (
                <Link
                  key={project.id}
                  to={`/projects/${project.id}`}
                  className="block px-4 py-2 text-sm text-[var(--color-muted)] hover:text-[var(--color-accent)] hover:bg-[var(--color-border)]/40 transition rounded-md"
                >
                  {project.title}
                </Link>
              ))}

            </div>
          </div>
        </div>

      </nav>
    </header>
  );
}
