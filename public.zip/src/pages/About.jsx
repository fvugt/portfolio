export default function About() {
  return (
    <section className="main-section">
      <h1 className="heading-xl mb-6">About Me</h1>

      <p className="body-text max-w-xl mb-4">
        Hier vertel ik iets over mijn skills, interesses en ambities als Game Developer.
      </p>
    </section>
  );
}
