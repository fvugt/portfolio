export default function Home() {
  return (
    <section className="main-section">
      <h1 className="heading-xl mb-4">Welkom op mijn portfolio</h1>
      
      <p className="body-text max-w-xl">
        In Week 2 heb ik navigatie, pagina's en een project-dropdown toegevoegd.
      </p>

      <div className="card mt-8">
        <p className="text-sm text-[var(--color-muted)] leading-relaxed">
          ✔ Header vernieuwd met neon-accent  
          ✔ Dropdown geladen vanuit JSON  
          ✔ Routing werkt met HashRouter  
        </p>
      </div>
    </section>
  );
}
