import { Outlet } from "react-router-dom";
import Header from "./components/Header";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="mt-16 border-t border-[var(--color-border)] py-6 text-center text-sm text-[var(--color-muted)]">
        © {new Date().getFullYear()} Mijn Portfolio
      </footer>
    </div>
  );
}
